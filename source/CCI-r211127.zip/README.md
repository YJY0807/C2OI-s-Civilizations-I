# 简体中文
* 	C2OI 文明1
* 	灵感: generals.io | 席德·梅尔 文明
* 	程序: YJY0807qwq
* 	平台: Windows
*   远古版本编译参数: -fno-asm -march=native -Ofast -m64 -pipe -static-libgcc -std=c++14 -Wall -lm -Wl,-stack=1073741824
*   最新版本: r211127
* 	更新日期: 2021/11/27
* 	bug反馈: https://github.com/YJY0807qwq/C2OI-Civilizations-I/issues/new
*   确认你的编译器支持c++20
* 	Copyright (c) 2021 C2OI Code&Game Studios | YJY0807qwq, All rights reserved.
* 	仅在洛谷和 Github 发布
# English
* 	C2OI's Civilizations I
* 	Idea: generals.io | Sid Meier's Civilizations 
* 	Code: YJY0807qwq
* 	Platform: Windows
* 	Old version's compile arguments: -fno-asm -march=native -Ofast -m64 -pipe -static-libgcc -std=c++14 -Wall -lm -Wl,-stack=1073741824
* 	Latest Version: r211127
* 	Update: 2021/11/27
* 	Bug report: https://github.com/YJY0807qwq/C2OI-Civilizations-I/issues/new
* 	Make sure your compiler supports c++20
* 	Copyright (c) 2021 C2OI Code&Game Studios | YJY0807qwq, All rights reserved.
* 	Only on Luogu and Github
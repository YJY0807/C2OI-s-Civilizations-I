#define BUILD_DLL

#include <console.hpp>
#include <windows.h>

using namespace std;

namespace Console
{
    EXPORT inline void cGotoXY(int x, int y)
    {
        HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
        COORD c;
        c.X = y;
        c.Y = x;
        SetConsoleCursorPosition(hStdout, c);
    }
    EXPORT inline void cSetColor(int t, int b)
    {
        HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hStdout, t + b * 16);
    }
}